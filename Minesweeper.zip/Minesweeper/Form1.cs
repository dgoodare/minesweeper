﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Minesweeper
{
    public partial class Form1 : Form
    {
        Label[,] cell = new Label[10, 10];
        Button[,] btn = new Button[10, 10];
        Random r = new Random();

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            newGame();
           
            button1.Visible = false;
        }

        void btnEvent_Click(object sender, EventArgs e)
        {
            //single click to flag
            if (((Button)sender).Text != "v")
            {
                ((Button)sender).Text = "v";
            } else {
                //hide button to reveal bombs/surrounding no
                ((Button)sender).Visible = false;

                //if button is a bomb
                if (((Button)sender).Tag == "0")
                {
                    textBox1.Text = "You hit a bomb!";
                }
            }
        }

        void newGame()
        {
            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 10; y++)
                {

                    //button initiation
                    btn[x, y] = new Button();
                    btn[x, y].SetBounds((30 * x), (30 * y), 30, 30);
                    btn[x, y].BackColor = Color.PowderBlue;
                    btn[x, y].Click += new EventHandler(this.btnEvent_Click);
                    Controls.Add(btn[x, y]);

                    //label initiation
                    cell[x, y] = new Label();
                    cell[x, y].Text = "x";
                    cell[x, y].Location = new Point((30 * x), (30 * y));
                    cell[x, y].Size = new Size(30, 30);
                    Controls.Add(cell[x, y]);

                }
            }

            assignBombs();
        }

        void assignBombs()
        {
            int nobombs = 0;

            //assign random bombs
            while (nobombs < 10)
            {
                //get random coordinates
                int randomx = r.Next(9);
                int randomy = r.Next(9);

                //if cell is empty, place bomb
                if (cell[randomx, randomy].Text == "x")
                {
                    cell[randomx, randomy].Text = "*";
                    //add 1 to no. bombs places
                    nobombs++;
                    btn[randomx, randomy].Tag = "0";
                }
            }

            countSurroundings();
        }

        void countSurroundings()
        {
            int neighbours;

            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 10; y++)
                {
                    neighbours = 0;

                    if (cell[x, y].Text == "x")
                    {
                        if (x > 0 && x < 9 && y > 0 && y < 9)
                        {
                            if (cell[x - 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //top left corner
                        if (x == 0 && y == 0)
                        {
                            if (cell[x + 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //bottom left corner
                        if (x == 0 && y == 9)
                        {
                            if (cell[x, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //bottom right corner
                        if (x == 9 && y == 9)
                        {
                            if (cell[x, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //top right corner
                        if (x == 9 && y == 0)
                        {
                            if (cell[x - 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //left side
                        if (x == 0 && !(y == 0 || y == 9))
                        {
                            if (cell[x, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //right side
                        if (x == 9 && !(y == 0 || y == 9))
                        {
                            if (cell[x, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //top edge
                        if (y == 0 && !(x == 0 || x == 9))
                        {
                            if (cell[x - 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y + 1].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }

                        //bottom edge
                        if (y == 9 && !(x == 0 || x == 9))
                        {
                            if (cell[x - 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x - 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            if (cell[x + 1, y - 1].Text == "*")
                            {
                                neighbours++;
                            }

                            //set cell to no of neighbours
                            cell[x, y].Text = Convert.ToString(neighbours);
                        }
                    }
                }
            }
        }

    }
}
